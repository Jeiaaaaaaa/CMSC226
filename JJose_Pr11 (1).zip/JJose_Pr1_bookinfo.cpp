/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include "bookinfo.h" //Include bookinfo header file

using namespace std;

/*This displays information about a book that the user wants to know about
* from invmenu.cpp, such as the isbn, title, author, publisher, date added,
* quantity on hand, wholesale cost, and retail price of a book.
*/
void bookInfo(char isbn[14], char title[51], char author[31], char publisher[31], 
			  char date[11], int qty, double wholesale, double retail)
{
	cout << "\tSerendipity Booksellers\n";
	cout << "\t   Book Information\n";
	cout << "\n";
	cout << "ISBN: " << isbn << endl;
	cout << "Title: " << title << endl;
	cout << "Author: " << author << endl;
	cout << "Publisher: " << publisher << endl;
	cout << "Date Added: " << date << endl;
	cout << "Quantity-On-Hand: " << qty << endl;
	cout << "Wholesale Cost: " << wholesale << endl;
	cout << "Retail Price: " << retail << endl;
	cout << "\n";
	return;
}
