//This header file contains the function prototypes
//of the bookdata program
#ifndef BOOKDATA_H
#define BOOKDATA_H

//Base class
class BookData
{
	protected:
		char bookTitle[51];
		char isbn[14];
		char author[31];
		char publisher[31];
		//char dateAdded[11];
		//int qtyOnHand;
		//double wholesale;
		//double retail;

	public:
		BookData(); //Default constructor

		//Setters
		void setTitle(char*);
		void setISBN(char*);
		void setAuthor(char*);
		void setPub(char*);
		//void setDateAdded(char*);
		//void setQty(int);
		//void setWholesale(double);
		//void setRetail(double);

		//Getters
		char* getTitle();
		char* getISBN();
		char* getAuthor();
		char* getPub();
		//char* getDateAdded();
		//int getQty();
		//int* getQtyAddress();
		//double getWholesale();
		//double* getWholesaleAddress();
		//double getRetail();

		//int isEmpty();
		//void removeBook(int);
		void strUpper2(char*);
		bool bookMatch(BookData &, char*);
};

#endif