//This header file contains the function prototypes
//of the invmenu program
#ifndef INVMENU_H
#define INVMENU_H

void invMenu();
void lookUpBook();
void addBook();
void editBook();
void deleteBook();
void strUpper1(char*);

#endif