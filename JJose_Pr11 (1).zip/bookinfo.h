//This header file contains the function prototypes
//of the bookinfo program
#ifndef BOOKINFO_H
#define BOOKINFO_H
#include <string>

using namespace std;


void bookInfo(char[], char[], char[], char[],
			 char[], int, double, double);

#endif


