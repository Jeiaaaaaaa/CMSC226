//This header file contains the function prototypes
//of the soldbook program
#ifndef SOLDBOOK_H
#define SOLDBOOK_H
#include "inventorybook.h" //Include inventorybook header file

//Derived class
class SoldBook : public InventoryBook
{
private:
	static double taxRate;
	int qtySold;
	double tax; // qtySold * retail * taxRate
	double subtotal; //retail * qtySold + tax 
	static double total;
	//char bookTitle[51];
	//char isbn[14];
	//char author[31];
	//char publisher[31];
	//char dateAdded[11];
	//int qtyOnHand;
	//double wholesale;
	//double retail;

public:
	SoldBook(); //Default constructor

	//Setters
	void setTaxRate(double);
	void setQtySold(int);
	//void setTax(double);
	//void setSubtotal(double);
	//void setTotal(double);
	//void setDateAdded(char*);
	//void setQty(int);
	//void setWholesale(double);
	//void setRetail(double);

	//Getters
	double getTaxRate() const;
	int getQtySold() const;
	double getTax();
	double getSubtotal();
	double getTotal();
	//char* getDateAdded();
	//int getQty();
	//int* getQtyAddress();
	//double getWholesale();
	//double* getWholesaleAddress();
	//double getRetail();

	//int isEmpty();
	//void removeBook(int);
	//void strUpper2(char*);
	//bool bookMatch(BookData&, char*);

};

#endif
