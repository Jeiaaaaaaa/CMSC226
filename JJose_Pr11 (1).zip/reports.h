//This header file contains the function prototypes
//of the reports program
#ifndef REPORTS_H
#define REPORTS_H

void reports();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();

#endif