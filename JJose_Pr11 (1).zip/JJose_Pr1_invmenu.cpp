/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
#include <string.h>
#include <fstream>
#include "bookdata.h" //Include bookdata header file
#include "bookinfo.h" //Include bookinfo header file
#include "invmenu.h" //Include invmenu header file
#include "inputvalid.h" //Include inputvalid header file
#include "soldbook.h" //Include soldbook header file

using namespace std;

const int BOOKS = 20;
extern InventoryBook book[BOOKS];
extern InputValid input;
extern fstream inventoryFile;
//extern char bookTitle[BOOKS][51]; //C-String 2D array that holds the title of each book
//extern char isbn[BOOKS][14]; //C-String 2D array that holds the isbn of each book
//extern char author[BOOKS][31]; //C-String 2D array that holds the author of each book
//extern char publisher[BOOKS][31]; //C-String 2D array that holds the publisher of each book
//extern char dateAdded[BOOKS][11]; //C-String 2D array that holds the date added of each book
//extern int qtyOnHand[BOOKS]; //int array that holds the quantity on hand of each book
//extern double wholesale[BOOKS]; //double array that holds the wholesale price of each book
//extern double retail[BOOKS]; //double array that holds the retail price of each book

/*
* This is a book inventory for the serendipity booksellers program. 
* It includes the functions whose purpose are to update the book
* inventory depending on what the user chooses to do, which can be to
* look up a book, add a book, edit a book, or delete a book.
*/
void invMenu()
{
	int choice = 0; //Variable for the choice

	//Display the invmenu until the user selects item five.
	while (choice != 5)
	{
		cout << "\tSerendipity Booksellers\n";
		cout << "\t  Inventory Database\n";
		cout << "\n";
		cout << "\t1. Look Up a book\n";
		cout << "\t2. Add a Book\n";
		cout << "\t3. Edit a Book's Record\n";
		cout << "\t4. Delete a Book\n";
		cout << "\t5. Return to the Main Menu\n";
		cout << "\n";
		cout << "\tEnter Your Choice: ";
		cin >> choice;
		cout << "\n";

		choice = input.isValidChoice(choice, 1, 5); //Input validation

		switch (choice)
		{
		case 1:
			lookUpBook(); //Calls the function lookUpBook
			break;
		case 2:
			addBook(); //Calls the function addBook
			break;
		case 3:
			editBook(); //Calls the function editBook
			break;
		case 4:
			deleteBook(); //Calls the function deleteBook
			break;
		case 5:
			cout << "\n\tYou selected item 5." << endl;
			cout << "\n";
			break;
		}
	}
	return;
}

/*
* This function asks the user what book they want to look up
* and it searches the book in the book inventory and displays the data about the book.
* If the book is not found, it tells the user that the book is not in the inventory.
*/
void lookUpBook()
{
	char answer = ' ';
	char title[51];
	int i = 0, r = 0;
	long number = 0;

	cout << "\tYou selected Look Up Book." << endl;
	cout << "\nEnter the title of the book that you want to look up: "; //Prompt the user to enter the title
	cin.ignore();
	cin.getline(title, 51);
	strUpper1(title); //To uppercase
	cout << "\n";
	inventoryFile.open("inventory.dat", ios::in | ios::binary); //Open the inventory file
	if (inventoryFile.fail()) //If the inventory file does not exist
	{
		inventoryFile.open("inventory.dat", ios::out| ios::binary); //Create an inventory file
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags
	}
	else
	{
		while (!inventoryFile.eof() && i < BOOKS) //Search the inventory file
		{
			number = i;
			inventoryFile.seekg(number * sizeof(book), ios::beg); //Seek a position in the inventory file
			inventoryFile.read(reinterpret_cast<char *>(&book), sizeof(book)); //Read the inventory file into the BookData structure
			book[i]; //Store the data that was read from the inventory file
			i++;
		}
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags 
	}
	for (r = 0; r < BOOKS; r++) //Search the bookTitle array
	{
		if (book[r].bookMatch(book[r], title)) //If the book title matches
		{
			cout << "Title: " << book[r].getTitle() << endl;
			cout << "Is this the book you were looking for? (Enter Y/y for yes or N/n for no): ";
			cin >> answer;
			cout << "\n";
			answer = input.isValidAnswer(answer, book[r].getTitle()); //Input Validation
			if (answer == 'Y' || answer == 'y') //If the book title is found
			{
				bookInfo(book[r].getISBN(), book[r].getTitle(), book[r].getAuthor(), book[r].getPub(),
					     book[r].getDateAdded(), book[r].getQty(), book[r].getWholesale(), book[r].getRetail());
				break;
			}
		}
	}
	if (r > BOOKS - 1) //If the book title is not found
	{
		cout << "The book is not in the inventory." << endl;
		cout << "\n";
	}
}

/*
* This function asks the user what book they want to add to the book inventory,
* asks them to enter the data about the book, and adds the book to the book inventory.
* If there is not enough capacity in the book inventory, it tells the user that the 
* book inventory is full.
*/
void addBook()
{
	char bookTitle[51]; //C-String 2D array that holds the title of each book
	char isbn[14]; //C-String 2D array that holds the isbn of each book
	char author[31]; //C-String 2D array that holds the author of each book
	char publisher[31]; //C-String 2D array that holds the publisher of each book
	char dateAdded[11]; //C-String 2D array that holds the date added of each book
	int qtyOnHand = 0; //int array that holds the quantity on hand of each book
	double wholesale = 0.0; //double array that holds the wholesale price of each book
	double retail = 0.0; //double array that holds the retail price of each book
	int i = 0, r = 0;
	long number1 = 0, number2 = 0;

	cout << "\tYou selected Add Book." << endl;
	inventoryFile.open("inventory.dat", ios::in | ios::binary); //Open the inventory file
	if (inventoryFile.fail()) //If the inventory file does not exist
	{
		inventoryFile.open("inventory.dat", ios::out | ios::binary); //Create an inventory file
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags 
	}
	else
	{
		while (!inventoryFile.eof() && i < BOOKS) //Search the inventory file
		{
			number1 = i;
			inventoryFile.seekg(number1 * sizeof(book), ios::beg); //Seek a position in the inventory file
			inventoryFile.read(reinterpret_cast<char *>(&book), sizeof(book)); //Read the inventory file into the BookData structure
			book[i]; //Store the data that was read from the inventory file
			i++;
		}
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags 
	}
	for (r = 0; r < BOOKS; r++) //Search the bookTitle array
	{
		if (book[r].isEmpty())
		{
			cout << "\nEnter the following fields:" << endl;
			cout << "\n";

			cout << "ISBN: ";
			cin.ignore();
			cin.getline(isbn, 14);
			book[r].setISBN(isbn);

			cout << "Title: ";
			cin.getline(bookTitle, 51);
			book[r].setTitle(bookTitle); 

			cout << "Author: ";
			cin.getline(author, 31);
			book[r].setAuthor(author);

			cout << "Publisher: ";
			cin.getline(publisher, 31);
			book[r].setPub(publisher); 

			cout << "Date Added: ";
			cin.getline(dateAdded, 11);
			book[r].setDateAdded(dateAdded); 

			cout << "Quantity-On-Hand: ";
			cin >> qtyOnHand;
			book[r].setQty(qtyOnHand);

			cout << "Wholesale Cost: ";
			cin >> wholesale;
			book[r].setWholesale(wholesale);

			cout << "Retail Price: ";
			cin >> retail;
			cout << "\n";
			book[r].setRetail(retail);
			
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		}
	}
	if (r > BOOKS - 1)
	{
		cout << "The inventory is full." << endl;
		cout << "\n";
	}
}

/*
* This function asks the user what book they want to edit
* and it searches the book in the book inventory and allows the user
* to edit any data about the book and saves it in the book inventory.
*  If the book is not found, it tells the user that the book is not in the inventory.
*/
void editBook()
{
	char bookTitle[51]; //C-String 2D array that holds the title of each book
	char isbn[14]; //C-String 2D array that holds the isbn of each book
	char author[31]; //C-String 2D array that holds the author of each book
	char publisher[31]; //C-String 2D array that holds the publisher of each book
	char dateAdded[11]; //C-String 2D array that holds the date added of each book
	int qtyOnHand = 0; //int array that holds the quantity on hand of each book
	double wholesale = 0.0; //double array that holds the wholesale price of each book
	double retail = 0.0; //double array that holds the retail price of each book
	bool value = false;
	char answer = ' ';
	int i = 0, r = 0, choice = 0;
	long number1 = 0, number2 = 0;
	
	cout << "\tYou selected Edit Book." << endl;
	cout << "\nEnter the title of the book that you want to edit: "; //Prompt the user to enter the title
	cin.ignore();
	cin.getline(bookTitle, 51);
	strUpper1(bookTitle); //to uppercase
	cout << "\n";
	inventoryFile.open("inventory.dat", ios::in | ios::binary); //Open the inventory file
	if (inventoryFile.fail()) //If the inventory file does not exist
	{
		inventoryFile.open("inventory.dat", ios::out | ios::binary); //Create an inventory file
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags
	}
	else
	{
		while (!inventoryFile.eof() && i < BOOKS) //Search the inventory file
		{
			number1 = i;
			inventoryFile.seekg(number1 * sizeof(book), ios::beg); //Seek a position in the inventory file
			inventoryFile.read(reinterpret_cast<char *>(&book), sizeof(book)); //Read the inventory file into the BookData structure
			book[i]; //Store the data that was read from the inventory file
			i++;
		}
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags 
	}
	for (r = 0; r < BOOKS; r++) //Search the bookTitle array
	{
		if (book[r].bookMatch(book[r], bookTitle))
		{
			cout << "Title: " << book[r].getTitle() << endl;
			cout << "Is this the book you were looking for? (Enter Y/y for yes or N/n for no): ";
			cin >> answer;
			cout << "\n";
			answer = input.isValidAnswer(answer, book[r].getTitle()); //Input Validation
			if (answer == 'Y' || answer == 'y') //If the book title is found
			{
				bookInfo(book[r].getISBN(), book[r].getTitle(), book[r].getAuthor(), book[r].getPub(),
					     book[r].getDateAdded(), book[r].getQty(), book[r].getWholesale(), book[r].getRetail());
				value = true;
				break;
			}
		}
	}
	if (value) //If the book title is found
	{
		cout << "Choose from the following fields:" << endl;
		cout << "\n";
		cout << "1. ISBN" << endl;
		cout << "2. Title" << endl;
		cout << "3. Author" << endl;
		cout << "4. Publisher" << endl;
		cout << "5. Date Added" << endl;
		cout << "6. Quantity-On-Hand" << endl;
		cout << "7. Wholesale Cost" << endl;
		cout << "8. Retail Price" << endl;
		cout << "9. Exit" << endl;
		cout << "\nEnter the field of the book that you want to edit (1-9): ";
		cin >> choice;
		cout << "\n";
		choice = input.isValidChoice(choice, 1, 9); //Input validation
		switch (choice)
		{
		case 1:
			cout << "Enter new ISBN: ";
			cin.ignore();
			cin.getline(isbn, 14);
			book[r].setISBN(isbn);
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 2:
			cout << "Enter new Title: ";
			cin.ignore();
			cin.getline(bookTitle, 51);
			book[r].setTitle(bookTitle);
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 3:
			cout << "Enter new Author: ";
			cin.ignore();
			cin.getline(author, 31);
			book[r].setAuthor(author); 
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 4:
			cout << "Enter new Publisher: ";
			cin.ignore();
			cin.getline(publisher, 31);
			book[r].setPub(publisher); 
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 5:
			cout << "Enter new Date Added: ";
			cin.ignore();
			cin.getline(dateAdded, 11);
			book[r].setDateAdded(dateAdded); 
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 6:
			cout << "Enter new Quantity-On-Hand: ";
			cin.ignore();
			cin >> qtyOnHand;
			book[r].setQty(qtyOnHand);
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 7:
			cout << "Enter new Wholesale Cost: ";
			cin.ignore();
			cin >> wholesale;
			book[r].setWholesale(wholesale);
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 8:
			cout << "Enter new Retail Price: ";
			cin.ignore();
			cin >> retail;
			book[r].setRetail(retail);
			cout << "\n";
			number2 = r;
			inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
			inventoryFile.seekp(number2 * sizeof(book), ios::beg);  //Seek a position in the inventory file
			inventoryFile.write(reinterpret_cast<char *>(&book), sizeof(book)); //Write the inventory file into the BookData structure
			inventoryFile.close(); //Close the inventory file
			inventoryFile.clear(); //Clear all flags 
			break;
		case 9:
			break;
		}
	}
	else //If the book title is not found
	{
		cout << "The book is not in the inventory." << endl;
		cout << "\n";
	}
}

/*
* This function asks the user what book they want to delete 
* and it searches the book in the book inventory and deletes the data about the book.
*  If the book is not found, it tells the user that the book is not in the inventory.
*/
void deleteBook()
{
	char bookTitle[51]; //C-String 2D array that holds the title of each book
	//char isbn[14]; //C-String 2D array that holds the isbn of each book
	//char author[31]; //C-String 2D array that holds the author of each book
	//char publisher[31]; //C-String 2D array that holds the publisher of each book
	//char dateAdded[11]; //C-String 2D array that holds the date added of each book
	//int qtyOnHand; //int array that holds the quantity on hand of each book
	//double wholesale; //double array that holds the wholesale price of each book
	//double retail; //double array that holds the retail price of each book
	bool value = false;
	char answer = 'Y';
	int i = 0, r = 0;
	long number = 0;
	cout << "\tYou selected Delete Book." << endl;
	cout << "\nEnter the title of the book you want to delete: ";
	cin.ignore();
	cin.getline(bookTitle, 51);
	strUpper1(bookTitle); //To uppercase
	cout << "\n";
	inventoryFile.open("inventory.dat", ios::in | ios::binary); //Open the inventory file
	if (inventoryFile.fail()) //If the inventory file does not exist
	{
		inventoryFile.open("inventory.dat", ios::out | ios::binary); //Create an inventory file
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags
	}
	else
	{
		while (!inventoryFile.eof() && i < BOOKS) //Search the inventory file
		{
			number = i;
			inventoryFile.seekg(number * sizeof(book), ios::beg); //Seek a position in the inventory file
			inventoryFile.read(reinterpret_cast<char *>(&book), sizeof(book)); //Read the inventory file into the BookData structure
			book[i]; //Store the data that was read from the inventory file
			i++;
		}
		inventoryFile.close(); //Close the inventory file
		inventoryFile.clear(); //Clear all flags 
	}
	for (r = 0; r < BOOKS; r++) //Search the bookTitle array
	{
		if (book[r].bookMatch(book[r], bookTitle)) //If the book titles match
		{
			cout << "Title: " << book[r].getTitle() << endl;
			cout << "Is this the book you were looking for? (Enter Y/y for yes or N/n for no): ";
			cin >> answer;
			cout << "\n";
			answer = input.isValidAnswer(answer, book[r].getTitle()); //Input Validation
			if (answer == 'Y' || answer == 'y') //If the book title is found
			{
				bookInfo(book[r].getISBN(), book[r].getTitle(), book[r].getAuthor(), book[r].getPub(),
					     book[r].getDateAdded(), book[r].getQty(), book[r].getWholesale(), book[r].getRetail());
				value = true;
				break;
			}
		}
	}
	if (value) //If the book title is found
	{
		cout << "Are you sure you want to delete this book? (Enter Y/y for yes or N/n for no): ";
		cin >> answer;
		cout << "\n";
		answer = input.isValidAnswer(answer); //InputValidation
		if (answer == 'Y' || answer == 'y') //Delete the book
		{
			book[r].removeBook(r); 
			cout << "The book has been deleted." << endl;
			cout << "\n";
		}
		else //Do not delete the book
		{
			cout << "The book has not been deleted." << endl;
			cout << "\n";
		}
	}
	else //If the book title is not found
	{
		cout << "The book is not in the inventory." << endl;
		cout << "\n";
	}
}

//This is the strUpper function 
void strUpper1(char* myString)
{
	while (*myString != 0) //Converts each character in a string to an uppercase letter
	{
		*myString = toupper(*myString);
		myString++;
	}
}

