//This header file contains the function prototypes
//of the inputvalid class
#ifndef INPUTVALID_H
#define INPUTVALID_H

class InputValid
{
	private:
		char answer;
		int choice;
	public:
		InputValid(); //Default constructor
	
		int isValidChoice(int, int, int);
		char isValidAnswer(char, char*);
		char isValidAnswer(char);
};


#endif
