/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <string.h>
#include "bookdata.h" //Include bookdata header file
#include "cashier.h" //Include cashier header file
#include "inputvalid.h" // Include inputvalid header file
#include "inventorybook.h" //Include inventorybook header file
#include "soldbook.h" //Include soldbook header file

using namespace std;

const int BOOKS = 20;
const double SALES_TAX = 0.06;
extern InventoryBook book[BOOKS];
extern InputValid input;
extern fstream inventoryFile;
//extern char bookTitle[BOOKS][51]; //C-String 2D array that holds the title of each book
//extern char isbn[BOOKS][14]; //C-String 2D array that holds the isbn of each book
//extern char author[BOOKS][31]; //C-String 2D array that holds the author of each book
//extern char publisher[BOOKS][31]; //C-String 2D array that holds the publisher of each book
//extern char dateAdded[BOOKS][11]; //C-String 2D array that holds the date added of each book
//extern int qtyOnHand[BOOKS]; //int array that holds the quantity on hand of each book
//extern double wholesale[BOOKS]; //double array that holds the wholesale price of each book
//extern double retail[BOOKS]; //double array that holds the retail price of each book

int shoppingCart = 0;
int cashierQty[BOOKS];
char cashierIsbn[BOOKS][14];
char cashierTitle[BOOKS][51];
//char titlesPurchased[51];
double cashierPrice[BOOKS];
double cashierSubtotal[BOOKS];
double cashierTotal[BOOKS];

string date; //Variable for the date
int quantity; //Variable for the quantity
bool value;
double tax = 0; //Variable for the tax
double price = 0; //Variable for the price
double total = 0; //Variable for the total
double subtotal = 0; //Variable for the subtotal
char answer = 'Y'; //Variable for the answer
int i = 0;
int inStock = 0;
int number = 0;
SoldBook* customerBooks; //Pointer to dynamically allocate SoldBook array
int titles = 0;
/*
**This is meant to function as a cash register that calculates the total sale including the
* sales tax and it displays the receipt of the purchase.
*/
void cashier()
{
	//Exception try/catch block
	try
	{
		inventoryFile.open("inventory.dat", ios::in | ios::binary); //Open the inventory file
	}
	catch (exception& e)
	{
		cout << "EXCEPTION: " << e.what();
	}
	while (!inventoryFile.eof() && i < BOOKS) //Search the inventory file
	{
		number = i;
		inventoryFile.read(reinterpret_cast<char*>(&book), sizeof(book)); //Read the inventory file into the BookData structure
		book[i]; //Store the data that was read from the inventory file
		if (!book[i].isEmpty())	//If title was found
		{
			inStock++;	//Store total number of titles in inventory
		}
		i++;
	}
	inventoryFile.close(); //Close the inventory file
	//Display the cashier until the user enters 'N' or 'n'.
	while (answer == 'Y' || answer == 'y')
	{
		cout << "Serendipity Booksellers\n";
		cout << "    Cashier Module\n";
		cout << "\n";
		cout << "Enter the date: ";
		cin.ignore();
		cin >> date;
		if (inStock == 0)
		{
			cout << "There are no books in the inventory. Please add books in the inventory." << endl;
			return;
		}
		cout << "Enter how many book titles will be purchased: ";
		cin >> titles;
		//cin.getline(titlesPurchased, 51)
		customerBooks = new SoldBook[titles]; //Dynamically allocate an array of SoldBook objects
		do	// repeat if duplicate ISBN is entered
		{
			// prompt the user to enter an ISBN
			cout << "Enter the ISBN: ";
			cin.ignore();
			cin.getline(cashierIsbn[shoppingCart], 14);
			for (int i = 0; i < shoppingCart; i++)
			{
				if (!strcmp(cashierIsbn[shoppingCart], customerBooks[i].getISBN()))
				{
					cout << "\nThat ISBN has already been entered." << endl;
					value = true;
				}
				else
				{
					value = false;
				}
			}
		} while (value);
		for (int r = 0; r < BOOKS; r++)
		{
			if (strcmp(cashierIsbn[shoppingCart], book[r].getISBN()) == 0) //If ISBN is found in inventory
			{
				cout << "Title: " << book[r].getTitle() << endl; //Title of the book
				cout << "Price: " << fixed << showpoint << setprecision(2) << book[r].getRetail() << endl; //Price of the book
				cout << "Quantity: " << book[r].getQty() << endl; //Quantity on hand of the book
				if (book[r].getQty() <= 0)
				{
					cout << "The book is out of stock." << endl;
					cout << "\n";
					return;
				}
				cout << "Enter the quantity of the book: ";
				cin >> quantity;
				while (book[r].getQty() < quantity || quantity <= 0)
				{
					if (book[r].getQty() < quantity) //here
					{
						cout << "There are not enough copies of the book in stock." << endl;
						cout << "\n";
						return;
					}
					else if (quantity <= 0)
					{
						cout << "Please enter a valid quantity." << endl;
					}
					cout << "Enter the quantity of the book: ";
					cin >> cashierQty[shoppingCart];
					cout << "\n";
				}
				// store book information in SoldBook objects
				customerBooks[shoppingCart].setISBN(book[r].getISBN());
				customerBooks[shoppingCart].setTitle(book[r].getTitle());
				customerBooks[shoppingCart].setRetail(book[r].getRetail());
				customerBooks[shoppingCart].setQtySold(quantity);
				customerBooks[shoppingCart].setTaxRate(SALES_TAX);
				book[r].setQty(book[r].getQty() - cashierQty[r]);
				//cashierQty[shoppingCart] = quantity;
				//int newQuantity = book[r].getQty();
				//cout << newQuantity << endl;
				//newQuantity -= quantity;
				//cout << newQuantity << endl;
				//book[r].setQty(newQuantity);
				//cout << book[r].getQty();
				//book[r].getQty() -= cashierQty[shoppingCart];
				shoppingCart++;
				cout << "Would you like to purchase another book? (Enter Y/y for yes or N/n for no): ";
				cin >> answer;
				cout << "\n";
				answer = input.isValidAnswer(answer); //Input Validation
				break;
			}
			else if (r == BOOKS - 1) //If ISBN is not found in inventory
			{
				cout << "ISBN is not found in inventory. Would you like to try again? (Enter Y/y for yes or N/n for no): ";
				cin >> answer;
				cout << "\n";
				answer = input.isValidAnswer(answer); //Input Validation
			}
		}
	}
	if (shoppingCart > 0) //If not empty
	{
		//Display the receipt
		cout << "\nSerendipity Booksellers\n";
		cout << "\n";
		cout << "Date: " << date << endl;
		cout << "\n";
		cout << "Qty" << "\tISBN" << "\t\tTitle" << "\t\t\t\tPrice" << "\t\tTotal\n";
		cout << "____________________________________________________________________________________\n\n\n";
		for (int i = 0; i < shoppingCart; i++)
		{
			//Perform the calculations
			subtotal += customerBooks[i].getSubtotal();
			tax += customerBooks[i].getTax();
			total += customerBooks[i].getTotal();
			//subtotal += cashierQty[i] * cashierPrice[i]; //Calculate the subtotal
			cout << customerBooks[i].getQtySold() << "\t" << left << setw(15) << customerBooks[i].getISBN() << "\t" << left << setw(30) << customerBooks[i].getTitle()
				 << "\t$ " << right << setw(7) << fixed << showpoint << setprecision(2) << customerBooks[i].getRetail()
				 << "\t$ " << right << setw(7) << fixed << showpoint << setprecision(2) << customerBooks[i].getSubtotal() << endl;
		}
		tax = subtotal * 0.06; //Calculate the tax
		total = subtotal + tax; //Calculate the total
		cout << "\n";
		cout << setw(15) << "" << "Subtotal\t\t\t\t\t\t\t$" << right << fixed << showpoint << setprecision(2) << setw(8) << subtotal << endl; //Display the subtotal
		cout << setw(15) << "" << "Tax\t\t\t\t\t\t\t$" << right << fixed << showpoint << setprecision(2) << setw(8) << tax << endl; //Display the tax
		cout << setw(15) << "" << "Total\t\t\t\t\t\t\t$" << right << fixed << showpoint << setprecision(2) << setw(8) << total << endl; //Display the total
		cout << "\n";
		cout << "\nThank You for Shopping at Serendipity!\n" << endl;
	}
	return;
}