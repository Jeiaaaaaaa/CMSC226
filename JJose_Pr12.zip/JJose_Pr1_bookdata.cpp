/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <cstring>
#include <fstream>
#include "bookdata.h" //Include bookdata header file
#include "invmenu.h"  //Include invmenu header file
#include "soldbook.h" //Include soldbookheader file

using namespace std;

const int BOOKS = 20;
extern InventoryBook book[BOOKS];
//extern fstream inventoryFile;

//This is the BookData constructor
BookData::BookData()
{

}

//This is the setTitle function
void BookData::setTitle(char* myTitle)
{
	strUpper2(myTitle);
	strcpy(this->bookTitle, myTitle);
}

//This is the setISBN function
void BookData::setISBN(char* myISBN)
{
	strUpper2(myISBN);
	strcpy(this->isbn, myISBN);
}

//This is the setAuthor function
void BookData::setAuthor(char* myAuthor)
{
	strUpper2(myAuthor);
	strcpy(this->author, myAuthor);
}

//This is the setPub function
void BookData::setPub(char* myPub)
{
	strUpper2(myPub);
	strcpy(this->publisher, myPub);
}

//This is the getTitle function
char* BookData::getTitle()
{
	return this->bookTitle;
}

//This is the getISBN function
char* BookData::getISBN()
{
	return this->isbn;
}

//This is the getAuthor function
char* BookData::getAuthor()
{
	return this->author;
}

//This is the getPub function
char* BookData::getPub()
{
	return this->publisher;
}

//This is the strUpper function 
void BookData::strUpper2(char* myString)
{
	while (*myString != 0) //Converts each character in a string to an uppercase letter
	{
		*myString = toupper(*myString);
		myString++;
	}
}

//This is the bookMatch function 
bool BookData::bookMatch(BookData &book, char* myString)
{
	bool value = false;
	if (strstr(book.getTitle(), myString))
	{
		value = true;
	}
	else
	{
		value = false;
	}
	return value;

}