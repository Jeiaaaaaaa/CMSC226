/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <cstring>
#include "bookdata.h" //Include bookdata header file
#include "cashier.h" //Include cashier header file
#include "inputvalid.h" //Include inputvalid header file
#include "invmenu.h"  //Include invmenu header file
#include "soldbook.h" //Include soldbook header file

using namespace std;

const int BOOKS = 20;
extern InventoryBook book[BOOKS];

//This is the InputValid default constructor
InputValid::InputValid()
{
	choice = 0;
	answer = 'Y';
}

//This is the isValidChoice Function
int InputValid::isValidChoice(int choice, int min, int max)
{
	while (choice < min || choice > max) //Input validation
	{
		cout << "\tPlease enter a valid choice in the range " << min << " - " << max << "." << endl;
		cout << "\n";
		cout << "\tEnter Your Choice: ";
		cin >> choice;
		cout << "\n";
	}
	return choice;
}

//This is the isValidAnswer Function that accepts a character and a c-string
char InputValid::isValidAnswer(char answer, char* title)
{
	while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n') //Input Validation
	{
		cout << "Please enter a valid answer." << endl;
		cout << "Title: " << title << endl;
		cout << "Is this the book you were looking for? (Enter Y/y for yes or N/n for no): ";
		cin >> answer;
		cout << "\n";
	}
	return answer;
}

//This is the isValidAnswer Function that accepts a character
char InputValid::isValidAnswer(char answer)
{
	while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n') //Input validation
	{
		cout << "Please enter a valid answer. (Enter Y/y for yes or N/n for no): ";
		cin >> answer;
		cin.ignore();
		cout << "\n";
	}
	return answer;
}