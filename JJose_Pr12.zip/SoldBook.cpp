#include <iostream>
#include <cstring>
#include <fstream>
#include "bookdata.h" //Include bookdata header file
#include "invmenu.h"  //Include invmenu header file
//#include "inventorybook.h" //Include inventorybook header file
#include "soldbook.h" //Include soldbook header file
using namespace std;

const int BOOKS = 20;
extern BookData book[BOOKS];
extern fstream inventoryFile;

double SoldBook::taxRate;
double SoldBook::total;

SoldBook::SoldBook()
{
	qtySold = 0;
}

void SoldBook::setTaxRate(double myTaxRate)
{
	this->taxRate = myTaxRate;
}

void SoldBook::setQtySold(int myQtySold)
{
	this->qtySold = myQtySold;
}

double SoldBook::getTaxRate() const
{
	return this->taxRate;
}

int SoldBook::getQtySold() const
{
	return this->qtySold;
}

double SoldBook::getTax()
{
	tax = qtySold * retail * taxRate;
	return this->tax;
}

double SoldBook::getSubtotal()
{
	subtotal = (retail * qtySold);
	return this->subtotal;
}

double SoldBook::getTotal()
{
	total = (subtotal + tax);
	return this->total;
}
