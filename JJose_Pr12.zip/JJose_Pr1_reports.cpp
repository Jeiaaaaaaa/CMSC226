/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory 
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
#include "bookdata.h" //Include bookdata header file
#include "inputvalid.h" //Include inputvalid header file
#include "reports.h" //Include reports header file
#include "soldbook.h" //Include soldbook header file

using namespace std;

const int BOOKS = 20;
extern InventoryBook book[BOOKS];
extern InputValid input;
//extern char bookTitle[BOOKS][51]; //C-String 2D array that holds the title of each book
//extern char isbn[BOOKS][14]; //C-String 2D array that holds the isbn of each book
//extern char author[BOOKS][31]; //C-String 2D array that holds the author of each book
//extern char publisher[BOOKS][31]; //C-String 2D array that holds the publisher of each book
//extern char dateAdded[BOOKS][11]; //C-String 2D array that holds the date added of each book
//extern int qtyOnHand[BOOKS]; //int array that holds the quantity on hand of each book
//extern double wholesale[BOOKS]; //double array that holds the wholesale price of each book
//extern double retail[BOOKS]; //double array that holds the retail price of each book

/*
**This is meant to function as a sales report that shows the details about the book inventory
* such as the book title, isbn, author, publisher, date added, quantity on hand, wholesale cost and retail price. 
* It can also display the information in a particular order depending on the user's choice.
*/
void reports()
{
	int choice = 0; //Variable for the choice
	
	//Display the reports until the user selects item seven.
	while (choice != 7)
	{
		cout << "\tSerendipity Booksellers\n";
		cout << "\t       Reports\n";
		cout << "\n";
		cout << "\t1. Inventory Listing\n";
		cout << "\t2. Inventory Wholesale Value\n";
		cout << "\t3. Inventory Retail Value\n";
		cout << "\t4. Listing by Quantity\n";
		cout << "\t5. Listing by Cost\n";
		cout << "\t6. Listing by Age\n";
		cout << "\t7. Return to Main Menu\n";
		cout << "\n";
		cout << "\tEnter your choice: ";
		cin >> choice;
		cout << "\n";

		choice = input.isValidChoice(choice, 1, 7); //Input Validation

		switch (choice)
		{
		case 1:
			repListing(); //Call function repListing
			break;
		case 2:
			repWholesale(); //Call function repWholesale
			break;
		case 3:
			repRetail(); //Call function repRetail
			break;
		case 4:
			repQty(); //Call function repQty
			break;
		case 5:
			repCost(); //Call function repCost
			break;
		case 6:
			repAge(); //Call function repAge
			break;
		case 7:
			cout << "\n\tYou selected item 7." << endl;
			cout << "\n";
			break;
		}

	}

	return;
}

//This is the repListing function
void repListing()
{
	char key;
	string date;
	cout << "\tYou selected Inventory Listing." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tInventory Listing" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		if (book[i].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[i].getTitle() << endl;
			cout << "ISBN: " << book[i].getISBN() << endl;
			cout << "Author: " << book[i].getAuthor() << endl;
			cout << "Publisher: " << book[i].getPub() << endl;
			cout << "Date Added: " << book[i].getDateAdded() << endl;
			cout << "Quantity-On-Hand: " << book[i].getQty() << endl;
			cout << "Wholesale Cost: $" << fixed << showpoint << setprecision(2) << book[i].getWholesale() << endl;
			cout << "Retail Price: $" << fixed << showpoint << setprecision(2) << book[i].getRetail() << endl;
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
}

//This is the repWholesale function
void repWholesale()
{
	char key;
	string date;
	double wholesaleTotal = 0.0;
	cout << "\tYou selected Inventory Wholesale Value." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tInventory Wholesale Value" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		if (book[i].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[i].getTitle() << endl;
			cout << "ISBN: " << book[i].getISBN() << endl;
			cout << "Quantity-On-Hand: " << book[i].getQty() << endl;
			cout << "Wholesale Cost: $" << fixed << showpoint << setprecision(2) << book[i].getWholesale() << endl;
			wholesaleTotal += (book[i].getQty() * book[i].getWholesale());
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
	cout << "Wholesale Total: $" << fixed << showpoint << setprecision(2) << wholesaleTotal << endl; //Total Wholesale Value
	cout << "\n";
}

//This is the repRetail function
void repRetail()
{
	char key;
	string date;
	double retailTotal = 0;
	cout << "\n\tYou selected Inventory Retail Value." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tInventory Retail Value" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		if (book[i].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[i].getTitle() << endl;
			cout << "ISBN: " << book[i].getISBN() << endl;
			cout << "Quantity-On-Hand: " << book[i].getQty() << endl;
			cout << "Retail Price: $" << fixed << showpoint << setprecision(2) << book[i].getRetail() << endl;
			retailTotal += (book[i].getQty() * book[i].getRetail());
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
	cout << "Retail Total: $" << fixed << showpoint << setprecision(2) << retailTotal << endl; //Total Retail Value
	cout << "\n";
}

//This is the repQty function
void repQty()
{
	char key;
	string date;
	int id[BOOKS];
	int* idPtr[BOOKS];
	int* qtyPtr[BOOKS];
	cout << "\n\tYou selected Listing By Quantity." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tListing By Quantity" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		id[i] = i;
		idPtr[i] = &id[i];
		qtyPtr[i] = book[i].getQtyAddress();
	}
	int maxIndex;
	int* tempId;
	int* maxValue;
	//Selection sort by quantity in descending order
	for (int k = 0; k < BOOKS - 1; k++)
	{
		maxIndex = k;
		maxValue = qtyPtr[k];
		tempId = idPtr[k];
		for (int l = k + 1; l < BOOKS; l++)
		{
			if (*(qtyPtr[l]) > *maxValue)
			{
				maxValue = qtyPtr[l];
				tempId = idPtr[l];
				maxIndex = l;
			}
		}       
		qtyPtr[maxIndex] = qtyPtr[k];
		idPtr[maxIndex] = idPtr[k];
		qtyPtr[k] = maxValue;
		idPtr[k] = tempId;
	}
	for (int j = 0; j < BOOKS; j++)
	{
		if (book[*(idPtr[j])].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[*(idPtr[j])].getTitle() << endl;
			cout << "ISBN: " << book[*(idPtr[j])].getISBN() << endl;
			cout << "Quantity-On-Hand: " << *qtyPtr[j] << endl;
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
	
}

//This is the repCost function
void repCost()
{
	char key;
	string date;
	int id[BOOKS];
	int* idPtr[BOOKS];
	double* costPtr[BOOKS];
	cout << "\n\tYou selected Listing By Cost." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tListing By Cost" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		id[i] = i;
		idPtr[i] = &id[i];
		costPtr[i] = book[i].getWholesaleAddress();
	}
	int maxIndex;
	int* tempId;
	double* maxValue;
	//Selection sort by wholesale cost in descending order
	for (int k = 0; k < BOOKS - 1; k++)
	{
		maxIndex = k;
		maxValue = costPtr[k];
		tempId = idPtr[k];
		for (int l = k + 1; l < BOOKS; l++)
		{
			if (*(costPtr[l]) > *maxValue)
			{
				maxValue = costPtr[l];
				tempId = idPtr[l];
				maxIndex = l;
			}
		}
		costPtr[maxIndex] = costPtr[k];
		idPtr[maxIndex] = idPtr[k];
		costPtr[k] = maxValue;
		idPtr[k] = tempId;
	}
	for (int j = 0; j < BOOKS; j++)
	{
		if (book[*(idPtr[j])].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[*(idPtr[j])].getTitle() << endl;
			cout << "ISBN: " << book[*(idPtr[j])].getISBN() << endl;
			cout << "Quantity-On-Hand: " << book[j].getQty() << endl;
			cout << "Wholesale Cost: $" << *costPtr[j] << endl;
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
}

//This is the repAge function
void repAge()
{
	char key;
	string date;
	int id[BOOKS];
	int* idPtr[BOOKS];
	char* agePtr[BOOKS];
	cout << "\n\tYou selected Listing By Age." << endl;
	cout << "\n";
	cout << "\tEnter the date: ";
	cin >> date;
	cout << "\n";
	cout << "\tListing By Age" << endl;
	cout << "\tDate: " << date << endl;
	cout << "\n";
	for (int i = 0; i < BOOKS; i++)
	{
		id[i] = i;
		idPtr[i] = &id[i];
		agePtr[i] = book[i].getDateAdded();
	}
	int maxIndex;
	int* tempId;
	char* maxValue;
	//Selection sort by age in descending order
	for (int k = 0; k < BOOKS - 1; k++)
	{
		maxIndex = k;
		maxValue = agePtr[k];
		tempId = idPtr[k];
		for (int l = k + 1; l < BOOKS; l++)
		{
			if (*(agePtr[l]) > *maxValue)
			{
				maxValue = agePtr[l];
				tempId = idPtr[l];
				maxIndex = l;
			}
		}
		agePtr[maxIndex] = agePtr[k];
		idPtr[maxIndex] = idPtr[k];
		agePtr[k] = maxValue;
		idPtr[k] = tempId;
	}
	for (int j = 0; j < BOOKS; j++)
	{
		if (book[*(idPtr[j])].getTitle()[0] != 0) //If not empty
		{
			cout << "Title: " << book[*(idPtr[j])].getTitle() << endl;
			cout << "ISBN: " << book[*(idPtr[j])].getISBN() << endl;
			cout << "Quantity-On-Hand: " << book[j].getQty() << endl;
			cout << "Date Added: " << book[*(idPtr[j])].getDateAdded() << endl;
			cout << "Press any key and enter to continue. ";
			cin.ignore();
			cin >> key;
			cout << "\n";
		}
	}
}

