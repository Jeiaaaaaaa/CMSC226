#include <iostream>
#include <cstring>
#include <fstream>
#include "bookdata.h" //Include bookdata header file
#include "invmenu.h"  //Include invmenu header file
#include "inventorybook.h" //Include inventorybook header file
#include "soldbook.h"//Include soldbook header file

using namespace std;

const int BOOKS = 20;
extern InventoryBook book[BOOKS];
extern fstream inventoryFile;

//This is the InventoryBook constructor
InventoryBook::InventoryBook()
{
	
}

//This is the setDateAdded function
void InventoryBook::setDateAdded(char* myDate)
{
	strUpper2(myDate);
	strcpy(this->dateAdded, myDate);
}

//This is the setQty function
void InventoryBook::setQty(int myQuantity)
{
	this->qtyOnHand = myQuantity;
}

//This is the setWholesale function
void InventoryBook::setWholesale(double myWholesale)
{
	this->wholesale = myWholesale;
}

//This is the setRetail function
void InventoryBook::setRetail(double myRetail)
{
	this->retail = myRetail;
}

//This is the getDateAdded function
char* InventoryBook::getDateAdded()
{
	return this->dateAdded;
}

//This is the getQty function
int InventoryBook::getQty()
{
	return this->qtyOnHand;
}

//This is the getQty function
int* InventoryBook::getQtyAddress()
{
	return &qtyOnHand;
}

//This is the getWholesale function
double InventoryBook::getWholesale()
{
	return this->wholesale;
}

//This is the getWholesaleAddress function
double* InventoryBook::getWholesaleAddress()
{
	return &wholesale;
}

//This is the getRetail function
double InventoryBook::getRetail()
{
	return this->retail;
}

int InventoryBook::isEmpty()
{
	if (this->bookTitle[0] == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void InventoryBook::removeBook(int subscript)
{
	long number = subscript;
	book[number].getTitle()[0] = 0;
	book[number].getISBN()[0] = 0;
	//Exception try/catch block:
	try
	{
		inventoryFile.open("inventory.dat", ios::out | ios::binary); //Open the inventory file
	}
	catch (exception &e)
	{
		cout << "EXCEPTION: " << e.what();
	}
	inventoryFile.seekp(number * sizeof(book), ios::beg);
	inventoryFile.write(reinterpret_cast<char*>(&book), sizeof(book)); //Write the inventory file into the BookData structure
	inventoryFile.close(); //Close the inventory file
	inventoryFile.clear(); //Clear all flags 
}