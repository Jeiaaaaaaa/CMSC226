//This header file contains the function prototypes
//of the cashier program
#ifndef CASHIER_H
#define CASHIER_H

void cashier();

#endif

