/*******************************************************************
** Program: Serendipity Booksellers Software Development Project Part 7-8
** Description: This program serves as a point-of-sale software that functions
as a cash register and book inventory for the Serendipity Booksellers bookstore.
It calculates the total of a sale with sales tax, updates and searches the inventory
of books, and displays the sales report.
** Course: CS226 CRN 33915
** Professor: Ping-Wei Tsai
** Student: Jeizen Feliz R. Jose
** Due Date: 04/25/2022
******************************************************************/

#include <iostream>
#include <fstream>
#include "bookinfo.h" //Include bookinfo header file
#include "cashier.h" //Include cashier header file
#include "inputvalid.h" //Include the inputvalid header file
#include "invmenu.h" //Include invmenu header file
#include "reports.h" //Include reports header file
#include "bookdata.h" //Include bookdata header file
#include "inventorybook.h" //Include inventorybook header file
#include "soldbook.h" //Include soldbook header file
using namespace std;

const int BOOKS = 20;
InventoryBook book[BOOKS];
fstream inventoryFile;
InputValid input;
//char bookTitle[BOOKS][51]; //C-String 2D array that holds the title of each book
//char isbn[BOOKS][14]; //C-String 2D array that holds the isbn of each book
//char author[BOOKS][31]; //C-String 2D array that holds the author of each book
//char publisher[BOOKS][31]; //C-String 2D array that holds the publisher of each book
//char dateAdded[BOOKS][11]; //C-String 2D array that holds the date added of each book
//int qtyOnHand[BOOKS]; //int array that holds the quantity on hand of each book
//double wholesale[BOOKS]; //double array that holds the wholesale price of each book
//double retail[BOOKS]; //double array that holds the retail price of each book

/***************************************************************************** 
**This serves as the control center that will help the user navigate the program.
*It includes the main menu for the serendipity booksellers store program.
******************************************************************************/
int main()
{
	int choice = 0; //Variable for the choice

	//Display the mainmenu until the user selects item four.
	while (choice != 4)
	{
		cout << "\tSerendipity Booksellers\n";
		cout << "\t      Main Menu\n";
		cout << "\n";
		cout << "\t1. Cashier Module\n";
		cout << "\t2. Inventory Database Module\n";
		cout << "\t3. Report Module\n";
		cout << "\t4. Exit\n";
		cout << "\n";
		cout << "\tEnter your choice: ";
		cin >> choice;
		cout << "\n";

		choice = input.isValidChoice(choice, 1, 4); //Input Validation

		switch (choice)
		{
		case 1:
			cashier(); //Call function cashier
			break;
		case 2:
			invMenu(); //Call function invMenu
			break;
		case 3:
			reports(); //Call function reports
			break;
		case 4:
			cout << "\n\tYou selected item 4." << endl;
			cout << "\n";
			break;
		}

	}

	return 0;
}
